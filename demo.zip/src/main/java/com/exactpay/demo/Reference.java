package com.exactpay.demo;

public class Reference {

    private String referenceNo;

    public Reference(String referenceNo) {
        this.referenceNo = referenceNo;


    }

    public String getReferenceNo() {
        return referenceNo;
    }

    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }
}
